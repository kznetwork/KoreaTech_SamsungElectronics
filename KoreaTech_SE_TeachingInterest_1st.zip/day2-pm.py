### Class
## 객체지향 프로그래밍 언어의 개요
# h = 10
# v = 20

# def Area(h, v):
#     return h * v

# a = Area(h, v)
# print(a)

class Rectangle(object):

    def __init__(self, h, v):
        self.h = h
        self.v = v

    def area(self):
        return self.h * self.v
    
# r = Rectangle(10, 20)
# a = r.area()
# print(a)

# print(r.h)
# print(r.v)
# print(r.area())

# a = Rectangle(1, 1)   # 가로 1, 세로 1인 사각형
# b = Rectangle(2, 1)   # 가로 2, 세로 1인 사각형
# c = Rectangle(4, 2)   # 가로 4, 세로 2인 사각형
# d = Rectangle(6, 3)   # 가로 6, 세로 3인 사각형
# e = Rectangle(8, 5)   # 가로 8, 세로 5인 사각형

# print(a.area())
# print(b.area())
# print(c.area())
# print(d.area())
# print(e.area())

# class Service:

#     def sum(self, a, b):
#         result = a + b
#         print("%s + %s = %s !!!" % (a,b, result))

# print(type(Service))

# pey = Service()
# type(pey)

# print(pey.sum( 1,1 ))

## Class – __del__

# class Park:
#     lastname = "Park"
#     def __init__(self, name):
#         self.fullname = self.lastname + name
#     def travel(self, where):
#         print("%s, %s Go!!" % (self.fullname, where))
#     def __del__(self):
#         print("%s Kill!!!" % self.fullname)

# pey = Park("MoonSu")

# del pey
##
# class Person:
#     age = 0
#     name = ''
#     def move(self):
#         print('이동!')
#     def stop():
#         print('정지!')
 
# p1 = Person()
# p1.move()
 
# Person.stop()


## 생성자란?
# class Counter:
#     def __init__(self) :
#         self.count = 0
#     def reset(self) :
#         self.count = 0
#     def increment(self):
#         self.count += 1
#     def get(self):
#         return self.count

## 메소드(Method)
# class Television:
# 	def __init__(self, channel, volume, on):
# 		self.channel = channel
# 		self.volume = volume
# 		self.on = on

# 	def show(self):
# 		print(self.channel, self.volume, self.on)

# 	def setChannel(self, channel):
# 		self.channel = channel

# 	def getChannel(self):
# 		return self.channel

# t = Television(9, 10, True)

# t.show()
# t.setChannel(11)
# t.show()

## 정보은닉

# class Student:
# 	def __init__(self, name=None, age=0):
# 		self.__name = name
# 		self.__age = age

# 	def getAge(self):
# 		return self.__age

# 	def getName(self):
# 		return self.__name

# 	def setAge(self, age):
# 		self.__age=age

# 	def setName(self, name):
# 		self.__name=name

# obj=Student("Hong", 20)
# print(obj.getName())


## Class – Inheritance (상속)
# class Park:
#     lastname = "Park"
#     def __init__(self, name):
#         self.fullname = self.lastname + name
#     def travel(self, where):
#         print("%s, %s Go!!" % (self.fullname, where))
#     def __del__(self):
#         print("%s Kill!!!" % self.fullname)

# GilDong = Park("GilDong")
# GilDong.travel("swimming")

# class Lee(Park):
#     lastname = "Lee"

# lee = Lee("SooShin")
# lee.travel("swimming")


# class Park:
#     lastname = "Park"
#     def __init__(self, name):
#         self.fullname = self.lastname + name
#     def travel(self, where):
#         print("%s, %s Go!!" % (self.fullname, where))
#     def __del__(self):
#         print("%s Kill!!!" % self.fullname)

# class Lee(Park):
#     lastname = "Lee"
#     def travel(self, where):
#         print("%s, %s fly in the sky!!" % (self.fullname, where))

# park = Park("MoonSu")
# lee = Lee("SoonShin")
# park.travel("Seoul")
# lee.travel("jeju island")
    
## 사례 1

# import math
# class Circle:
# 	def __init__(self, radius=1.0):
# 		self.__radius = radius

# 	def setRadius(self, r):
# 		self.__radius = r

# 	def getRadius(self):
# 		return self.__radius

# 	def calcArea(self):
# 		area = math.pi*self.__radius*self.__radius
# 		return area
# 	def calcCircum(self):
# 		circumference = 2.0*math.pi*self.__radius
# 		return circumference

# c1=Circle(10)
# print("원의 반지름=", c1.getRadius())
# print("원의 넓이=", c1.calcArea())
# print("원의 둘레=", c1.calcCircum())


## 사례 2 - 재난지원금
# class 재난지원금(object):

#     def __init__(self):
#         self.life = 1000

#     def 지출(self):
#         self.life -= 10
#         print("지출! =", self.life)

# a = 재난지원금()
# b = 재난지원금()
# c = 재난지원금()

# print("모든 객체의 초기 life 속성값은 모두 1000이다.")
# print(a.life, b.life, c.life)

# print("지출!을 하면 지원금은 감소된다.")
# print(a.지출())

# print(b.지출())

# a.지출()
# a.지출()
# a.지출()
# a.지출()
# a.지출()

# print("지출 후 남은 life 속성값")
# print(a.life, b.life, c.life)

### Quizzes
# class House:
#     # 매물 초기화 : 위치, 건물 종류, 매물 종류, 가격, 준공년도
#     def __init__(self, location, house_type, deal_type, price, completion_year):
#         self.location = location
#         self.house_type = house_type
#         self.deal_type = deal_type
#         self.price = price
#         self.completion_year = completion_year

#     # 매물 정보 표시
#     def show_detail(self):
#         print(self.location, self.house_type, self.deal_type, 
#         self.price, self.completion_year)


# houses = []
# house1 = House("강남", "아파트", "매매", "10억", "2010년")
# house2 = House("마포", "오피스텔", "전세", "5억", "2007년")
# house3 = House("송파", "빌라", "월세", "500/50", "2000년")

# houses.append(house1)
# houses.append(house2)
# houses.append(house3)

# print("총 {0}대의 매물이 있습니다.".format(len(houses)))
# for house in houses:
#     house.show_detail()


###
# import mo1
# print(mo1.sum(5,10))

# from mo1 import sum
# print(sum(5,10))

# from travel import thailand
# trip_to = thailand.ThailandPackage()
# trip_to.detail()

# import mypackage.sound.echo
# mypackage.sound.echo.echo_test()

# from mypackage.sound import echo
# echo.echo_test()

# from mypackage.sound.echo import echo_test
# echo_test()

# from mypackage.sound import *
# echo.echo_test()

### # Exceptions - try-except

#f = open("not exist file", 'r')

#4/0

# a = [1,2,3]
# a[4]

# def getMean(numericValues):
#   return sum(numericValues)/len(numericValues)
  
# my_list2 = [ ]

# try:
#   print("Output #1: {}".format(getMean(my_list2)))
# except ZeroDivisionError as detail:
#   print("Output #2 (Error): {}".format(float('nan')))
#   print("Output #3 (Error): {}".format(detail))


##
# print("나누기 전용 계산기입니다.")
# num1 = int(input("첫 번째 숫자를 입력하세요 : "))
# num2 = int(input("두 번째 숫자를 입력하세요 : "))
# print("{0} / {1} = {2}".format(num1, num2, int(num1/num2)))

# try:
#     print("나누기 전용 계산기입니다.")
#     num1 = int(input("첫 번째 숫자를 입력하세요 : "))
#     num2 = int(input("두 번째 숫자를 입력하세요 : "))
#     print("{0} / {1} = {2}".format(num1, num2, int(num1/num2)))
# except ValueError:
#     print("에러! 잘못된 값을 입력하였습니다.")
# except ZeroDivisionError as err:
#     print(err)

# try:
#     print("나누기 전용 계산기입니다.")
#     nums = []
#     nums.append(int(input("첫 번째 숫자를 입력하세요 : ")))
#     nums.append(int(input("두 번째 숫자를 입력하세요 : ")))
#     # nums.append(int(nums[0] / nums[1])) # 계산 결과를 리스트에 추가
#     print("{0} / {1} = {2}".format(nums[0], nums[1], nums[2]))
# except ValueError:
#     print("에러! 잘못된 값을 입력하였습니다.")
# except ZeroDivisionError as err:
#     print(err)
# except Exception as err:
#     print("알 수 없는 에러가 발생하였습니다.")
#     print(err)

# class BigNumberError(Exception):
#     def __init__(self, msg):
#         self.msg = msg

#     def __str__(self):
#         return self.msg

# try:
#     print("한 자리 숫자 나누기 전용 계산기입니다.")
#     num1 = int(input("첫 번째 숫자를 입력하세요: "))
#     num2 = int(input("두 번째 숫자를 입력하세요: "))
#     if num1 >= 10 or num2 >= 10:
#         raise BigNumberError("입력값 : {0}, {1}".format(num1, num2))
#     print("{0} / {1} = {2}".format(num1, num2, int(num1 / num2)))
# except ValueError:
#     print("잘못된 값을 입력하였습니다. 한 자리 숫자만 입력하세요.")
# except BigNumberError as err:
#     print("에러가 발생하였습니다. 한 자리 숫자만 입력하세요.")
#     print(err)
# finally: # 에러 발생 여부 상관 없이 항상 실행
#     print("계산기를 이용해 주셔서 감사합니다.")

#####

company = '삼성전자,LG전자,현대자동차,CJ,SK텔레콤'

print(company.find('전자'))
print(company.index('전자'))

# company= '삼성전자,LG전자,현대자동차,CJ,SK텔레콤'

# print(company.find('네이버'))
# print(company.index('네이버'))

# company= '삼성전자,LG전자,현대자동차,CJ,SK텔레콤'

# try:
#     print(company.index('전자'))
# except ValueError:
#     print("-1")

# company= '삼성전자,LG전자,현대자동차,CJ,SK텔레콤'

# try:
#     print(company.index('네이버'))
# except ValueError:
#     print("-1")


# company= '삼성전자,LG전자,현대자동차,CJ,SK텔레콤'

# index = 0
# while index > -1:
#     index = company.find('전자', index)
#     if index > -1:
#         print(index)
#         index += len('전자')

#####

company = '삼성전자,LG전자,현대자동차,CJ,SK텔레콤'

print(company.find('전자'))
print(company.index('전자'))

# company= '삼성전자,LG전자,현대자동차,CJ,SK텔레콤'

# print(company.find('네이버'))
# print(company.index('네이버'))

# company= '삼성전자,LG전자,현대자동차,CJ,SK텔레콤'

# try:
#     print(company.index('전자'))
# except ValueError:
#     print("-1")

# company= '삼성전자,LG전자,현대자동차,CJ,SK텔레콤'

# try:
#     print(company.index('네이버'))
# except ValueError:
#     print("-1")


# company= '삼성전자,LG전자,현대자동차,CJ,SK텔레콤'

# index = 0
# while index > -1:
#     index = company.find('전자', index)
#     if index > -1:
#         print(index)
#         index += len('전자')

company= '삼성전자,LG전자,현대자동차,CJ,SK텔레콤'

index = 0
while index > -1:
    try:
        index = company.index('전자', index)
        print(index)
        index += len('전자')
    except ValueError:
        break






#####


### 내장 함수
# print(abs(3))
# print(abs(-3))
# print(abs(1+5j))
# print(chr(65))
# print(dir([1,2,3]))
# print(dir({'1':'a'}))
# print(divmod(7,3))
# print(divmod(7.3,0.3))
# print(eval('1+2'))
# print(eval("'hi' + 'a'"))
# print(eval('divmod(4,3)'))
# for i, name in enumerate(["JamaicanBlueMountain", "KenyaAA", "SumatraMandheling","ColombianMilds","Santos"]):
#     print(i, name)

# def positive(l):
#     result = []
#     for i in l:
#         if i > 0:
#             result.append(i)
#     return result
# print(positive([1, -3, 2, 0, -5, 6]))

# def positive(x):
#     return x>0
# print(list(filter(positive, [1, -3, 2, 0, -5, 6])))

# print(hex(234))
# print(hex(3))

# a = 3
# print(id(3))
# print(id(a))
# b = a
# b = print(id(b))

# a = input()
# print(a)
# b = input("Enter: ")
# print(b)

# print(int('3'))
# print(int(3.4))
# print(int('11', 2))
# print(int('1A', 16))

# class Person: pass
# a = Person()
# b = 3
# isinstance(a, Person)
# isinstance(b, Person)

# len("python")

# def two_times(l):
#     result = []
#     for i in l:
#         result.append(i*2)
#     return result

# result = two_times([1,2,3,4])
# print(result)


# def two_times(x): return x*2

# print(list(map(two_times, [1,2,3,4])))

# print(list(map(lambda a: a*2, [1,2,3,4])))

# print(max([1,2,3]))
# print(max("python"))

# print(min([1,2,3]))
# print(min("python"))

# print(oct(34))
# print(oct(123456))

# print(ord('a'))
# print(ord('0'))

# print(repr("hi".upper()))

# print(sorted([3,1,2]))
# print(sorted("zero"))

# print(str(3))
# print(str('hi'))

# print(list(zip([1,2,3],[4,5,6])))

