### Lists
# a = []
# b = [1, 2, 3]
# c = ['Life', 'is', 'too', 'short']
# d = [1, 2, 'Life', 'is']
# e = [1, 2, ['Life', 'is']]
# print(a)
# print(b)
# print(c)
# print(d)
# print(e)

### Lists- Index values
# L1 = [ 1, 2, 3]
# print(L1)
# print(L1[0])
# print(L1[0] + L1[2])
# print(L1[-1])
# L2 = [ 1, 2, 3, ['a', 'b', 'c']]
# print(L2[0])
# print(L2[-1])
# print(L2[3])
# print(L2[-1][0])
# print(L2[-1][1])
# L3 = [1, 2, ['a', 'b', ['Life', 'is']]]
# print(L3[2][2][0])


### Lists- List slices(분할)
# L1 = [1, 2, 3, 4, 5]
# print(L1[0:2])
# L2 = "12345"
# print(L2[0:2])
# L3 = [1, 2, 3, 4, 5]
# L4 = L3[:2]
# L5 = L3[2:]
# print(L4)
# print(L5)
# L6 = [1, 2, 3, ['a', 'b', 'c'], 4, 5]
# print(L6[2:5])
# print(L6[3][:2])

### Lists- list 병합
# L1 = [1, 2, 3]
# L2 = [4, 5, 6]
# print(L1 + L2)
# print(L1 * 3)

### Lists- list   editing & deletion
# L1 = [1, 2, 3]
# print(L1)
# L1[2] = 4
# print(L1)
# print(L1[1:2])
# L1[1:2] = ['a', 'b', 'c']
# print(L1)
# L1[1:3] = []
# print(L1)
# del L1[1]
# print(L1)

### Lists- in and not in
# L1 = [1, 2, 3]
# print(2 in L1)
# print(4 in L1)
# print(2 not in L1)
# print(4 not in L1)

### Lists- List function

# L1 = [1, 2, 3]

# L1.append(4)
# L1.append(5)
# L1.append(6)
# print("Output #83: {}".format(L1))
# L1.remove(5)
# print("Output #84: {}".format(L1))
# L1.pop()
# L1.pop()
# print("Output #85: {}".format(L1))

# unordered_list = [3, 5, 1, 7, 2, 8, 4, 9, 0, 6]
# print("Output #88: {}".format(unordered_list))
# list_copy = unordered_list[:]
# list_copy.sort()
# print("Output #89: {}".format(list_copy))

## List Comprehension

# my_list = [1, 2, 3, 4, 5]
# new_list = [x for x in my_list if x > 3]
# print(new_list)

# CoffeeBean = ["JamaicanBlueMountain", "KenyaAA", "SumatraMandheling","ColombianMilds","Santos"]
# recall = [ ] # 리콜 대상 제품 리스트
# for p in CoffeeBean:
#     if p.startswith("S"): # CoffeeBean이 S 로 시작하는가?
#         recall.append(p)
# print(recall)

# CoffeeBean = ["JamaicanBlueMountain", "KenyaAA", "SumatraMandheling","ColombianMilds","Santos"]
# recall = [p for p in CoffeeBean if p.startswith("S")]
# print(recall)

# CoffeeBean = ["JamaicanBlueMountain", "KenyaAA", "SumatraMandheling","ColombianMilds","Santos"]
# # 모든 CoffeeBean 뒤에 SE (Special Edition) 을 붙인다
# CoffeeBean_se = [p + "SE" for p in CoffeeBean]
# print(CoffeeBean_se)

# # 모든 CoffeeBean을 소문자로 바꾼다
# CoffeeBean_lower = [p.lower() for p in CoffeeBean]
# print(CoffeeBean_lower)

# # "S"자가 있는 CoffeeBean만 뽑는데 뒤에 (최신형) 이라는 글자를 붙인다
# CoffeeBean_new = [p+" - New 2023" for p in CoffeeBean if p.endswith("s")]
# print(CoffeeBean_new)

# my_list = ["korea", "English", "france"]
# new_list = [x.upper() for x in my_list if "a" in x]
# print(new_list)

### Tuples

# T1 = ()
# T2 = (1,)
# T3 = (1, 2, 3)
# T4 = 1, 2, 3
# T5 = ('a', 'b', ('ab', 'cd'))
# print(T1)
# print(T2)
# print(T3)
# print(T4)
# print(T5)
# T3[0] = 100

# my_tuple = ('x', 'y', 'z')
# print("Output #1: {}".format(my_tuple))
# print("Output #2: my_tuple has {} elements".format(len(my_tuple)))
# print("Output #3: {}".format(my_tuple[1]))
# longer_tuple = my_tuple + my_tuple
# print("Output #4: {}".format(longer_tuple))

#Unpack tuples
# my_tuple = ('x', 'y', 'z')
# one, two, three = my_tuple
# print("Output #1: {0} {1} {2}".format(one, two, three))
# var1 = 'red'
# var2 = 'robin'
# print("Output #2: {} {}".format(var1, var2))
# # 변수 var1, var2 = var2, var1 간의 값 교환
# var1, var2 = var2, var1
# print("Output #3: {} {}".format(var1, var2))

# Tuples-튜플을 list으로 변환(또는 그 반대로)

# my_list = [1, 2, 3]
# my_tuple = ('x', 'y', 'z')
# print("Output #1: {}".format(tuple(my_list)))
# print(type(my_list))
# my_list_t = tuple(my_list)
# print(type(my_list_t))
# print("Output #2: {}".format(list(my_tuple)))
# print(type(my_tuple))
# my_tuple_l =  list(my_tuple)
# print(type(my_tuple_l))

### Dictionaries

# empty_dict = { }
# a_dict = {'one':1, 'two':2, 'three':3}
# print("Output #1: {}".format(a_dict))
# print("Output #2: a_dict has {!s} elements".format(len(a_dict)))
# another_dict = {'x':'printer', 'y':5, 'z':['star', 'circle', 9]}
# print("Output #3: {}".format(another_dict))
# print("Output #4: another_dict also has {!s} elements".format(len(another_dict)))

# print("Output #5: {}".format(a_dict['two']))
# print("Output #6: {}".format(another_dict['z']))

# print("Output #7: {}".format(a_dict.keys()))
# a_dict_keys = a_dict.keys()
# print("Output #8: {}".format(a_dict_keys))
# print("Output #9: {}".format(a_dict.values()))
# print("Output #10: {}".format(a_dict.items()))

# a_new_dict = a_dict.copy()
# print("Output #11: {}".format(a_new_dict))

# in, not in, and get
# a_dict = {'one':1, 'two':2, 'three':3}
# another_dict = {'x':'printer', 'y':5, 'z':['star', 'circle', 9]}
# if 'y' in another_dict:
#   print("Output #1: y is a key in another_dict: {}.".format(another_dict.keys()))
# if 'c' not in another_dict:
#   print("Output #2: c is not a key in another_dict: {}.".format(another_dict.keys()))
# print("Output #3: {!s}".format(a_dict.get('three')))
# print("Output #4: {!s}".format(a_dict.get('four')))
# print("Output #5: {!s}".format(a_dict.get('four', 'Not in dict')))

### Set

# CompanyA = {"JamaicanBlueMountain", "KenyaAA", "SumatraMandheling"} # CompanyA CoffeeBean 집합
# CompanyB = set(["JamaicanBlueMountain", "Mocha"]) # CompanyB CoffeeBean 집합

# #교집합
# print(CompanyA & CompanyB) # {'JamaicanBlueMountain'}
# print(CompanyA.intersection(CompanyB)) # {'JamaicanBlueMountain'}

# #합집합
# print(CompanyA | CompanyB) # {'Mocha', 'JamaicanBlueMountain', 'KenyaAA', 'SumatraMandheling'}
# print(CompanyA.union(CompanyB)) # {'Mocha', 'JamaicanBlueMountain', 'KenyaAA', 'SumatraMandheling'}

# #차집합
# print(CompanyA - CompanyB) # {'SumatraMandheling', 'KenyaAA'}
# print(CompanyA.difference(CompanyB)) # {'SumatraMandheling', 'KenyaAA'}

# #추가
# CompanyB.add("KenyaAA")
# print(CompanyB) # {'Mocha', 'JamaicanBlueMountain', 'KenyaAA'}

# #삭제
# CompanyA.remove("KenyaAA")
# print(CompanyA) # {'JamaicanBlueMountain', 'SumatraMandheling'}


### Python’s Statement
## 비교
# x=5
# if x > 4:
#   print("Output #1: {}".format(x)) 
# else:
#   print("Output #2: x is not greater than 4")

# x=5
# if x > 6:
#   print("Output #125: x is greater than six")
# elif x > 4 and x == 5:
#   print("Output #1: {}".format(x*x))
# else:
#   print("Output #2: x is not greater than 4")



# CoffeeBean = ["ColombianMilds", "EthiopianHarrar", "EthiopianYirgacheffe"]
# if 'EthiopianYirgacheffe' in CoffeeBean:
#     pass
#     print("pass")
# else:
#     print("ColombianMilds, EthiopianHarrar")


# Quizzes-숫자 맞추기 연습
# print("숫자게임에 오신 것을 환영합니다.")
# number = 62
# s = input("1부터 100 사이의 숫자를 추측해보세요: ")
# guess = int(s)
# if guess == number:
#     print("맞았습니다.")
# else:
#     print("틀렸습니다.")
# print("게임이 종료되었습니다.")

### 반복문

# for loops

# starbucks = ["ColombianMilds", "EthiopianHarrar", "EthiopianYirgacheffe"] # CoffeeBean 리스트
# for CoffeeBean in starbucks:
#     print("{0}, 커피가 준비되었습니다".format(CoffeeBean))

# sum = 0
# for i in range(1, 11):
#     sum += i

# print(sum)

# dic = {1:1, 2:4, 3:9} 
# for key in dic:
#     print('key=', key, 'value=', dic[key])

# while loops

# print("Output #1:")
# x=0
# while x < 11:
#   print("{!s}".format(x))
#   x += 1

# CoffeeBean = "Mocha"
# index = 1
# while True:
#     print("{0}, 커피가 준비 되었습니다. 호출 {1} 회".format(CoffeeBean, index))
#     index += 1

# # Quizzes- 숫자 맞추기
# import random

# tries = 0
# number = random.randint(1, 100)

# print("1부터 100 사이의 숫자를 맞추시오")

# while tries < 10:
#     guess = int(input("숫자를 입력하시오: "))
#     tries = tries + 1
#     if guess < number:
#         print("낮음!")
#     elif guess > number:
#         print("높음!")
#     else:
#         break

# if guess == number:
#      print("축하합니다. 시도횟수=", tries)
# else:
#      print("정답은 ", number)


# Customer = [2, 5] # 자리를 뜬 손님

# for waitingNumber in range(1, 11): # 대기번호 1~10번
#     if waitingNumber in Customer: # 호출 손님이 자리를 떴을 경우, 다음 손님으로 이동
#         continue
#     print("{0}, 번 손님!!!".format(waitingNumber))

# absent = [2, 5] # 결석한 학생 출석번호
# no_book = [7] # 책을 가져오지 않은 학생 출석번호

# for student in range(1, 11): # 출석번호 1~10번
#     if student in absent: # 결석했으면 책을 읽지 않고 다음 학생으로 넘어가기
#         continue
#     elif student in no_book: # 책을 가져오지 않았으면 바로 수업 종료 (반복문 탈출)
#         print("오늘 수업 여기까지. {0}는 교무실로 따라와".format(student))
#         break
#     print("{0}, 책을 읽어봐".format(student))

# # Quiz
# from random import *

# cnt = 0 # 총 탑승 승객 수
# for i in range(1, 51): # 총 50분의 승객
#     time = randrange(5, 51) # 5분 ~ 50분 사이의 소요 시간
    
#     if 5 <= time <= 15: # 5분 ~ 15분 사이의 손님의 경우 매칭 성공
#         print("[O] {0}번째 손님 (소요시간 : {1}분)".format(i, time)) # 성공 정보 출력
#         cnt += 1 # 총 탑승 승객 수 증가 처리
#     else: # 매칭 실패한 경우
#         print("[ ] {0}번째 손님 (소요시간 : {1}분)".format(i, time)) # 실패 정보 출력

# print("총 탑승 승객 : {0}분".format(cnt))


### Python’s 함수

# def sum(a,b):
#     return a+b

# print(sum(3,4))

# def say():
#     return 'hello'

# a = say()

# print(a)

# def say():
#     print("hello")

# a = say()

# print(say())

# def sum_many(*args):
#     sum =  0
#     for i in args:
#         sum += i
#     return sum

# print(sum_many(1,2,3,4,5))

# def sum_mul(choice, *args):
#     if choice == 'mul':
#         result = 1
#         for i in args:
#             result *= i
#     else:
#         result = 0
#         for i in args:
#             result += i
#     return result

# print(sum_mul('mul', 1,2,3,4,5))

# def sum_and_mul(a, b):
#     return (a+b, a*b)

# print(sum_and_mul(3,4))


# def say_nick(nick):
#     if nick == 'fool':
#         return
#     print(nick)

# say_nick('genius')

# say_nick('fool')

# def say_name_nick(name, nick='genius'):
#     print(name, nick)

# say_name_nick('Dave')

# say_name_nick('Dave','fool')


##
# def var_test(a):
#     a += 1
#     b = a
#     return a

# a = 1
# print(var_test(a))

# print(a)

# #print(b)

# a = 1
# a = var_test(a)
# print(a)

# a = 1

# def var_test():
#     global a
#     a += 1

# var_test()

# print(a)

# a = 1

# def var_test():
#     a += 1

# var_test()

### 참조값에 의한 인수 전달
## 값에 의한 호출(call-by-value)
# def modify1(s):
# 	s += "To You"

# msg = "Happy Birthday"
# print("msg=", msg)
# modify1(msg)
# print("msg=", msg)

# T = (1,2,3)

# def Test(x):
# 	x += (4,5,6)
	
# Test(T)

# print(T)

##참조에 의한 호출(call by reference)
# def modify2(li):
#     li += [100, 200]

# list = [1, 2, 3, 4, 5]
# print(list)
# modify2(list)
# print(list)

# T = [1,2,3]

# def Test(x):
# 	x += [4,5,6]
	
# Test(T)

# print(T)

### 함수는 객체(object)
# def oTest(a,b):
#     print(a,b)

# x = oTest
# print(x(1,2))

# print(oTest)

# print(x)

# def oTest(f, a):
#     return f(a)

# def square(x):
#     return x*x

# print(oTest(square,3))

# def oTest(x):
#     def bar(y):
#         return x+y
#     return bar

# f =  oTest(3)

# print(f)

# print(f(2))


### Anonymous Function
# def Sum1(a,b):
#     return a*b
# print(Sum1(10,10))

# Sum2=lambda a,b:a+b
# print(Sum2(3,4))

# lambda_list = [ lambda a, b: a + b, lambda a, b: a * b ]
# print(lambda_list)
 
# result1 = lambda_list[0](3, 4)
# print(result1)
 
# result2 = lambda_list[1](3, 4)
# print(result2)


# CoffeeBean = ["JamaicanBlueMountain", "KenyaAA", "SumatraMandheling","ColombianMilds","Santos"]
# CoffeeBean.sort(key=lambda x: len(set(list(x))))
# print(CoffeeBean)

## 가변인자

def visit(today, *customers):
    print(today)
    for customer in customers:
        print(customer)
        
visit("2023년 05월 01일", "박문수") # 1명 방문
visit("2023년 05월 02일", "박문수", "이순신") # 2명 방문
visit("2023년 05월 03일", "박문수", "이순신", "임꺽정") # 3명 방문


### Quizzes
# def readList():
# 	nlist = []
# 	flag = True;
# 	while flag :
# 		number = int(input("숫자를 입력하시오: "))
# 		if number < 0:
# 			flag = False
# 		else :
# 			nlist.append(number)
# 	return nlist

# def processList(nlist):
# 	nlist.sort()
# 	return nlist


# def printList(nlist):
# 	for i in nlist:
# 		print("성적=", i)

# def main():
# 	nlist = readList()
# 	processList(nlist)
# 	printList(nlist)

# if __name__ == "__main__":
# 	main()

### 더하기, 빼기, 곱하기, 나누기 기능이 가능한 사칙연산 계산기 함수 만들기
# class FourCal:
# 	def setdata(self, first, second):
# 		self.first = first
# 		self.second = second
# 	def add(self):
# 		result = self.first + self.second
# 		return result
# 	def mul(self):
# 		result = self.first * self.second
# 		return result
# 	def sub(self):
# 		result = self.first - self.second
# 		return result
# 	def div(self):
# 		result = self.first / self.second
# 		return result

# a = FourCal()
# b = FourCal()
# a.setdata(4, 2)
# b.setdata(3, 8)

# print(a.add())
# print(a.mul())
# print(a.sub())
# print(a.div())
# print(b.add())
# print(b.mul())
# print(b.sub())
# print(b.div())


### 몇 가지 함수 연습
## 5보다 큰 수만 필터링하여 돌려주는 함수를 lambda와 List Comprehension을 이용하는 함수로 작성
# def myfunc(numbers):
#     result = []
#     for number in numbers:
#         if number > 5:
#             result.append(number)
#     return result
 
# result = myfunc([2, 3, 4, 5, 6, 7, 8])
# print(result)

##
# 첫 번째 정수를 입력하시오: 5
# 두 번째 정수를 입력하시오: 10
# 합은  15
##
# Integer1 = int(input("첫 번째 정수를 입력하시오: "))
# Integer2 = int(input("두 번째 정수를 입력하시오: "))
# sum=lambda a,b:a+b
# print("합은 ", sum(Integer1 ,Integer2))


### Quizzes
# def std_weight(height, gender): # 키 m 단위 (실수), 성별 "남자" / "여자"
#     if gender == "남자":
#         return height * height * 22
#     else:
#         return height * height * 21

# height = 175 # cm 단위
# gender = "남자"
# weight = round(std_weight(height / 100, gender), 2) # 소수점 둘째자리까지 반올림
# print("키 {0}cm {1}의 표준 체중은 {2}kg 입니다.".format(height, gender, weight))