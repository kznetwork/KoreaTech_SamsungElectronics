from random import *

# print(int(random() * 45) + 1)
# print(int(random() * 45) + 1)
# print(int(random() * 45) + 1)
# print(int(random() * 45) + 1)
# print(int(random() * 45) + 1)
# print(int(random() * 45) + 1)

# print(int(random() * 45) + 1)
# print( randrange(1, 46))
#print(randint(1, 45))

# import random

# lotto = []
# rnd_num = random.randint(1, 45)

# for i in range(6):
#     while rnd_num in lotto:
#         rnd_num = random.randint(1, 45)
#     lotto.append(rnd_num)

# lotto.sort()
# print("로또번호: {}".format(lotto))

# import random

# lotto = random.sample(range(1, 45), 6)
# print("로또번호: {}".format(lotto))

# import numpy

# lotto = numpy.random.choice(range(1, 46), 6, replace=False)
# print("로또번호: {}".format(lotto))

# import random

# def fill_random_number(numbers: list):
#     rand_num = random.randint(1, 45)
#     for i in range(len(numbers), 6):
#         while rand_num in numbers:
#             rand_num = random.randint(1, 45)
#         numbers.append(rand_num)
#     numbers.sort()

# def make_lotto(**kwargs):
#     lotto = []

#     if kwargs.get("include"):
#         include = kwargs.get("include")
#         lotto.extend(include)
#         fill_random_number(lotto)
#     return lotto

# print("로또번호:{}".format(make_lotto(include=[4,5,6])))

# import random

# def fill_random_number(numbers: list):
#     rand_num = random.randint(1, 45)
#     for i in range(len(numbers), 6):
#         while rand_num in numbers:
#             rand_num = random.randint(1, 45)
#         numbers.append(rand_num)
#     numbers.sort()

# def make_lotto(**kwargs):
#     lotto = []

#     if kwargs.get("exclude"):
#       exclude = kwargs.get("exclude")
#       while(len(lotto) != 6):
#           fill_random_number(lotto)
#           lotto = list(set(lotto) - set(exclude))
#     return lotto

# print("로또번호:{}".format(make_lotto(exclude =[4,5,6])))

