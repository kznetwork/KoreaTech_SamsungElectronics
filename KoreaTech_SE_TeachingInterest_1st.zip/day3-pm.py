### 파이썬 표준 입/출력
# print("Coffee", "Tea")
# print("Coffee" + "Tea")

# print("Coffee", "Tea", sep=",") # 값들을 콤마(,) 로 구분
# print("Coffee", "Tea", "Smoothie", sep=" vs ") # 값들을 " vs " 로 구분
# print("Coffee", "Tea", sep=",", end="?")
# print("무엇이 더 맛있을까요?")

# scores = {"국어":100, "수학":50, "영어":80}

# for subject, score in scores.items(): # key, value
#     print(subject, score)]

# scores = {"국어":100, "수학":50, "영어":80}

# for subject, score in scores.items():
#     print(subject.ljust(8), str(score).rjust(4), sep=":")

# for num in range(1, 21): # 1~20 까지의 숫자
#     print("대기번호 : " + str(num))

# for num in range(1, 21): # 1~20 까지의 숫자
#     print("대기번호 : " + str(num).zfill(3))

###

# print("[{:<20}]".format("*"))
# print("[{:>20}]".format("*"))
# print("[{:^20}]".format("*"))
# print("[{:20.5f}]".format(1 / 3))
# print("[{:20,}]".format(1234567890))

# print("[{:-<20}]".format("*"))
# print("[{:->20}]".format("*"))
# print("[{:-^20}]".format("*"))

# number = 1234567
# print(f"[{number:<20}]")
# print(f"[{number:>20}]")
# print(f"[{number:^20}]")
# print(f"[{number:-<20}]")
# print(f"[{number:->20}]")
# print(f"[{number:-^20}]")
# print(f"[{number:-^20,}]")

# f_number = 3.141592
# print(f"[{f_number:20.3f}]")


###

#!/usr/bin/env python3
from math import exp, log, sqrt
import re
from datetime import date, time, datetime, timedelta
from operator import itemgetter
import sys

# print("Output ###: ")
# filereader = open("data/first_text.txt", 'r')
# for row in filereader:
#   print(row.strip())
# filereader.close()


# F1=open("data/first_text.txt",'r')
# line=F1.readline()
# print(line)
# F1.close()

# F1=open("data/first_text.txt",'r')
# while True:
#   line=F1.readline()
#   if not line:
#     break
#   print(line)
# F1.close()

# F2=open("data/first_text.txt",'r')
# line=F2.read()
# print(line)
# F2.close()

# F3=open("data/first_text.txt",'a')
# for i in range(11,20):
#   line = "%d번째 줄입니다. \n" % i
#   F3.write(line)
# F3.close()


# F4=open("data/first_text.txt",'r')
# line=F4.read()
# print(line)
# F4.close()

# F5=open("data/noWith.txt",'w')
# F5.write("Life is too short, you need python!!!")
# F5.close()

# with open("data/With.txt",'w') as F6:
#   F6.write("Life is too short, you need python!!!")

# my_letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
# max_index = len(my_letters)
# filewriter = open("data/second_text.txt", 'w')
# for index_value in range(len(my_letters)):
#   if index_value < (max_index-1):
#     filewriter.write(my_letters[index_value]+'\t')
#   else:
#       filewriter.write(my_letters[index_value]+'\n')
# filewriter.close()
# print("Output ###: Output written to file")


###
# import pickle # pickle 모듈 가져다 쓰기

# profile_file = open("Mymodules/Coffee_pickle.pickle", "rb") # 읽을 때에도 바이너리(binary) 명시
# profile = pickle.load(profile_file) # file 에 있는 정보를 불러와서 profile 에 저장

# print(profile)
# profile_file.close()

### Quizzes
# for i in range(1, 51):
#     with open(str(i) + "주차.txt", "w", encoding="utf8") as report_file:
#         report_file.write("- {0} 주차 주간보고 -".format(i))
#         report_file.write("\n부서 : ")
#         report_file.write("\n이름 : ")
#         report_file.write("\n업무 요약 : ")

### 간단한 사칙 연산 계산기
# def add(x, y):
#     return x + y

# def subtract(x, y):
#     return x - y

# def multiply(x, y):
#     return x * y

# def divide(x, y):
#     return x / y

# print("사칙연산을 선택 하세요.")
# print("1.더하기")
# print("2.빼기")
# print("3.곱하기")
# print("4.나누기")

# choice = input("선택 하세요(1/2/3/4):")

# num1 = int(input("첫번째 숫자 : "))
# num2 = int(input("두번째 숫자 : "))

# if choice == '1':
#     print(num1,"+",num2,"=", add(num1,num2))

# elif choice == '2':
#     print(num1,"-",num2,"=", subtract(num1,num2))

# elif choice == '3':
#     print(num1,"*",num2,"=", multiply(num1,num2))

# elif choice == '4':
#     print(num1,"/",num2,"=", divide(num1,num2))
# else:
#     print("잘못된 선택")

### Tkinter를 사용한 GUI 계산기

# import tkinter as tkt

# root = tkt.Tk()
# root.title("계산기")
# root.resizable(0, 0)                                # 윈도우 크기 고정한다
# root.wm_attributes("-topmost", 1)                   # 화면 상단에 유지된다.

# # 변수 선언
# equa = ""
# equation = tkt.StringVar()

# calculation = tkt.Label(root, textvariable=equation)
# equation.set("계산식을 입력하세요 : ")
# calculation.grid(row=2, columnspan=8)


# def btnPress(num):
#     global equa
#     equa = equa + str(num)
#     equation.set(equa)

# def EqualPress():
#     global equa
#     total = str(eval(equa))
#     equation.set(total)
#     equa = ""

# def ClearPress():
#     global equa
#     equa = ""
#     equation.set("")

# Button0 = tkt.Button(root, text="0", bg='white',command=lambda: btnPress(0), height=1, width=7, borderwidth=1, relief=tkt.SOLID)
# Button0.grid(row=6, column=2, padx=10, pady=10)
# Button1 = tkt.Button(root, text="1", bg='white',command=lambda: btnPress(1), height=1, width=7, borderwidth=1, relief=tkt.SOLID)
# Button1.grid(row=3, column=1, padx=10, pady=10)
# Button2 = tkt.Button(root, text="2", bg='white',command=lambda: btnPress(2), height=1, width=7, borderwidth=1, relief=tkt.SOLID)
# Button2.grid(row=3, column=2, padx=10, pady=10)
# Button3 = tkt.Button(root, text="3", bg='white',command=lambda: btnPress(3), height=1, width=7, borderwidth=1, relief=tkt.SOLID)
# Button3.grid(row=3, column=3, padx=10, pady=10)
# Button4 = tkt.Button(root, text="4", bg='white',command=lambda: btnPress(4), height=1, width=7, borderwidth=1, relief=tkt.SOLID)
# Button4.grid(row=4, column=1, padx=10, pady=10)
# Button5 = tkt.Button(root, text="5", bg='white',command=lambda: btnPress(5), height=1, width=7, borderwidth=1, relief=tkt.SOLID)
# Button5.grid(row=4, column=2, padx=10, pady=10)
# Button6 = tkt.Button(root, text="6", bg='white',command=lambda: btnPress(6), height=1, width=7, borderwidth=1, relief=tkt.SOLID)
# Button6.grid(row=4, column=3, padx=10, pady=10)
# Button7 = tkt.Button(root, text="7", bg='white',command=lambda: btnPress(7), height=1, width=7, borderwidth=1, relief=tkt.SOLID)
# Button7.grid(row=5, column=1, padx=10, pady=10)
# Button8 = tkt.Button(root, text="8", bg='white',command=lambda: btnPress(8), height=1, width=7, borderwidth=1, relief=tkt.SOLID)
# Button8.grid(row=5, column=2, padx=10, pady=10)
# Button9 = tkt.Button(root, text="9", bg='white',command=lambda: btnPress(9), height=1, width=7, borderwidth=1, relief=tkt.SOLID)
# Button9.grid(row=5, column=3, padx=10, pady=10)
# Plus = tkt.Button(root, text="+", bg='white',command=lambda: btnPress("+"), height=1, width=7, borderwidth=1, relief=tkt.SOLID)
# Plus.grid(row=3, column=4, padx=10, pady=10)
# Minus = tkt.Button(root, text="-", bg='white',command=lambda: btnPress("-"), height=1, width=7, borderwidth=1, relief=tkt.SOLID)
# Minus.grid(row=4, column=4, padx=10, pady=10)
# Multiply = tkt.Button(root, text="*", bg='white',command=lambda: btnPress("*"), height=1, width=7, borderwidth=1, relief=tkt.SOLID)
# Multiply.grid(row=5, column=4, padx=10, pady=10)
# Divide = tkt.Button(root, text="/", bg='white',command=lambda: btnPress("/"), height=1, width=7, borderwidth=1, relief=tkt.SOLID)
# Divide.grid(row=6, column=4, padx=10, pady=10)
# Equal = tkt.Button(root, text="=", bg='white',command=EqualPress, height=1, width=7, borderwidth=1, relief=tkt.SOLID)
# Equal.grid(row=6, column=3, padx=10, pady=10)
# Clear = tkt.Button(root, text="C", bg='white',command=ClearPress, height=1, width=7, borderwidth=1, relief=tkt.SOLID)
# Clear.grid(row=6, column=1, padx=10, pady=10)

# root.mainloop()