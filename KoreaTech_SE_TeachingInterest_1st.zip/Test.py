if True:
    print("True") 
else:
    print("False") 