def run():
    print("Contact")

if __name__ == "__main__":
    run()