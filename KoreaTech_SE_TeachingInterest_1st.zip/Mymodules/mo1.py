def sum(a, b):
    return a + b

if __name__ == "__main__":
    print(sum(1,4))