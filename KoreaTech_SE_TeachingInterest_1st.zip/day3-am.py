### 모듈과 import
## Os
# import os
# print(os.environ['PATH'])

# import os
# print(os.getcwd())

# import time
# print(time.time()) # 1970년 1월 1일 0시 0분 0초를 기준으로 지난 시간을 초단위로 돌려줌

# print(time.ctime()) #알아보기 쉬운 날짜와 시간 형태의 값을 반환하여 주는 함수

# # time.sleep 함수는 보통 루프 안에서 많이 쓰이는데 일정한 시간 간격을 주기 위해서 주로 사용됨
# for i in range(10):
#     print(i)
#     time.sleep(1)

from math import exp, log, sqrt
import re
from datetime import date, time, datetime, timedelta

# today = date.today()
# print("Output #1: today: {0!s}".format(today))
# print("Output #2: {0!s}".format(today.year))
# print("Output #3: {0!s}".format(today.month))
# print("Output #4: {0!s}".format(today.day))
# current_datetime = datetime.today()
# print("Output #5: {0!s}".format(current_datetime))

# today = date.today()
# one_day = timedelta(days=-1)
# yesterday = today + one_day
# print("Output #1: yesterday: {0!s}".format(yesterday))
# eight_hours = timedelta(hours=-8)
# print("Output #2: {0!s} {1!s}".format(eight_hours.days, eight_hours.seconds))

# today = date.today()
# print("Output #1: {:s}".format(today.strftime('%m/%d/%Y')))
# print("Output #2: {:s}".format(today.strftime('%b %d, %Y')))
# print("Output #3: {:s}".format(today.strftime('%Y-%m-%d')))
# print("Output #4: {:s}".format(today.strftime('%B %d, %Y')))


# today = date.today()
# # 날짜를 나타내는 문자열에서 # 특정 형식의 datetime 객체 생성
# date1 = today.strftime('%m/%d/%Y')
# date2 = today.strftime('%b %d, %Y')
# date3 = today.strftime('%Y-%m-%d')
# date4 = today.strftime('%B %d, %Y')
# # 두 개의 datetime 객체와 두 개의 날짜 객체
# # 날짜 형식이 다른 4개의 문자열 기반
# print("Output #1: {!s}".format(datetime.strptime(date1, '%m/%d/%Y')))
# print("Output #2: {!s}".format(datetime.strptime(date2, '%b %d, %Y')))
# # 날짜 부분만 표시
# print("Output #3: {!s}".format(datetime.date(datetime.strptime(date3, '%Y-%m-%d'))))
# print("Output #4: {!s}".format(datetime.date(datetime.strptime(date4, '%B %d, %Y'))))


## Quiz
# import timeit
# start_time = timeit.default_timer() 

# sum = 0

# for i in range(100000000):
#     sum += i

# terminate_time = timeit.default_timer()

# print("%f초 걸렸습니다." % (terminate_time - start_time))

## Random
# import random
# print(random.random())
# print( random.randint(1,10))
# print(random.randint(1,55))

# import random
# print(random.random())

# print(random.uniform(3,4))

# print(
#     [
#      random.randrange(20) for i in range(10)
#     ]
# )

# L1=list(range(10))
# print(L1)

## Quizzes

## 가위 바위 보 게임

# import random;

# player = input("(가위, 바위, 보) 중에서 하나를 선택하세요: ");

# number = random.randint(0,2);
# if (number == 0):
#     computer = "가위";
# elif (number == 1):
#     computer = "바위";
# else:
#     computer = "보";
# print("사용자: ", player, "컴퓨터: ", computer)

# if (player == computer):
#     print("비겼음!");
# elif (player == "바위"):
#     if (computer == "보"):
#         print("컴퓨터가 이겼음!");
#     else:
#         print("사용자가 이겼음!");
# elif (player == "보"):
#     if (computer == "비위"):
#         print("사용자가 이겼음!");
#     else:
#         print("컴퓨터가 이겼음!");
# elif (player == "가위"):
#     if (computer == "바위"):
#         print("컴퓨터가 이겼음!");
#     else:
#         print("사용자가 이겼음!");

# from random import *

# users = range(1, 21)
# users = list(users)
# shuffle(users)

# winners = sample(users, 4)

# print(" -- 당첨자 발표 -- ")
# print("치킨 당첨자 : {0}".format(winners[0]))
# print("커피 당첨자 : {0}".format(winners[1:]))
# print(" -- 축하합니다 --")

### Math
# import math

# print(dir(math))

# print(math.pow(2, 10))
               
# print(math.pi)


### 외부 라이브러리
# import sys
# print("python 버전 : {}".format(sys.version))


# import pandas as pd
# print("pandas 버전 : {}".format(pd.__version__))


# import matplotlib
# print("matplotlib 버전 : {}".format(matplotlib.__version__))


# import numpy as np
# print("numpy 버전 : {}".format(np.__version__))

## Numpy

# import numpy as np
# print(np.array([1, 2, 3]))
# print(np.arange(10))
# print(np.linspace(0,2,4))
# print(np.zeros((2,4)))

# import numpy as np
# a = np.array([1,2,3,6])
# b = np.linspace(0,2,4)
# c = a - b
# print(c)
# print(a**2)

# import numpy as np
# import math

# a = np.linspace(-np.pi, np.pi, 3)
# print(a)

# print(np.cos(a))

# print(math.cos(a))

# import matplotlib.pyplot as plt

# x = [1, 2, 3]
# y = [2, 4, 8]
# plt.plot(x, y)
# plt.show()

# import matplotlib.pyplot as plt

# plt.plot([-1, 0, 1], [-5, -1, 2])
# plt.show()

# import matplotlib.pyplot as plt

# x = [1, 2, 3]
# y = [2, 4, 8]
# plt.plot(x, y)
# plt.title('Line Graph')
# plt.show()


# import matplotlib
# import matplotlib.pyplot as plt
# matplotlib.rcParams['font.family'] = 'Malgun Gothic' # Windows
# # matplotlib.rcParams['font.family'] = 'AppleGothic' # Mac
# matplotlib.rcParams['font.size'] = 15 # 글자 크기
# matplotlib.rcParams['axes.unicode_minus'] = False # 한글 폰트 사용 시, 마이너스 글자가 깨지는 현상을 해결

# # import matplotlib.font_manager as fm
# # fm.fontManager.ttflist # 사용 가능한 폰트 확인
# # print([f.name for f in fm.fontManager.ttflist])

# x = [1, 2, 3]
# y = [2, 4, 8]

# plt.plot(x, y)
# plt.title('꺾은선 그래프')
# plt.show()

# import matplotlib.pyplot as plt
# import matplotlib
# matplotlib.rcParams['font.family'] = 'Malgun Gothic' # Windows
# # matplotlib.rcParams['font.family'] = 'AppleGothic' # Mac
# matplotlib.rcParams['font.size'] = 15 # 글자 크기
# matplotlib.rcParams['axes.unicode_minus'] = False # 한글 폰트 사용 시, 마이너스 글자가 깨지는 현상을 해결

# x = [1, 2, 3]
# y = [2, 4, 8]

# plt.plot(x, y)
# plt.xlabel('X축')
# plt.ylabel('Y축')
# plt.show()

# import matplotlib.pyplot as plt
# import matplotlib
# matplotlib.rcParams['font.family'] = 'Malgun Gothic' # Windows
# # matplotlib.rcParams['font.family'] = 'AppleGothic' # Mac
# matplotlib.rcParams['font.size'] = 15 # 글자 크기
# matplotlib.rcParams['axes.unicode_minus'] = False # 한글 폰트 사용 시, 마이너스 글자가 깨지는 현상을 해결

# x = [1, 2, 3]
# y = [2, 4, 8]

# plt.plot(x, y, label='범례')
# plt.legend(loc=(0.7, 0.8)) # x축, y축 (0~1 사이)
# plt.show()

# import matplotlib.pyplot as plt
# import matplotlib
# matplotlib.rcParams['font.family'] = 'Malgun Gothic' # Windows
# # matplotlib.rcParams['font.family'] = 'AppleGothic' # Mac
# matplotlib.rcParams['font.size'] = 15 # 글자 크기
# matplotlib.rcParams['axes.unicode_minus'] = False # 한글 폰트 사용 시, 마이너스 글자가 깨지는 현상을 해결

# x = [1, 2, 3]
# y = [2, 4, 8]

# plt.figure(figsize=(10, 5), dpi=150, facecolor='yellow') # dots per inch, 확대
# plt.plot(x, y, 
#          linewidth=5,
#          marker='o', markersize=20, markeredgecolor='red', markerfacecolor='yellow',
#          linestyle='-.',
#          color='g'         
#          )
# plt.show()

# import matplotlib.pyplot as plt
# import matplotlib
# matplotlib.rcParams['font.family'] = 'Malgun Gothic' # Windows
# # matplotlib.rcParams['font.family'] = 'AppleGothic' # Mac
# matplotlib.rcParams['font.size'] = 15 # 글자 크기
# matplotlib.rcParams['axes.unicode_minus'] = False # 한글 폰트 사용 시, 마이너스 글자가 깨지는 현상을 해결

# x = [1, 2, 3]
# y = [2, 4, 8]

# plt.figure(dpi=200)
# plt.plot(x, y)
# plt.show()
# plt.savefig('graph_200.png', dpi=100)

# import matplotlib.pyplot as plt
# import matplotlib
# matplotlib.rcParams['font.family'] = 'Malgun Gothic' # Windows
# # matplotlib.rcParams['font.family'] = 'AppleGothic' # Mac
# matplotlib.rcParams['font.size'] = 15 # 글자 크기
# matplotlib.rcParams['axes.unicode_minus'] = False # 한글 폰트 사용 시, 마이너스 글자가 깨지는 현상을 해결

# x = [1, 2, 3]
# y = [2, 4, 8]

# plt.plot(x, y, marker='o')

# for idx, txt in enumerate(y):
#     plt.text(x[idx], y[idx] + 0.3, txt, ha='center', color='blue')

# plt.show()

# import matplotlib.pyplot as plt
# import matplotlib
# matplotlib.rcParams['font.family'] = 'Malgun Gothic' # Windows
# # matplotlib.rcParams['font.family'] = 'AppleGothic' # Mac
# matplotlib.rcParams['font.size'] = 15 # 글자 크기
# matplotlib.rcParams['axes.unicode_minus'] = False # 한글 폰트 사용 시, 마이너스 글자가 깨지는 현상을 해결

# days = [1, 2, 3] # 1일, 2일, 3일
# az = [2, 4, 8] # (단위 : 만명) 1일부터 3일까지 아스트라제네카 접종인구
# pfizer = [5, 1, 3] # 화이타
# moderna = [1, 2, 5] # 모더나

# # plt.plot(days, az, label='az')
# # plt.plot(days, pfizer, label='pfizer', marker='o', linestyle='--')
# # plt.plot(days, moderna, label='moderna', marker='s', ls='-.')

# # plt.legend()

# plt.plot(days, az, label='az')
# plt.plot(days, pfizer, label='pfizer', marker='o', linestyle='--')
# plt.plot(days, moderna, label='moderna', marker='s', ls='-.')

# plt.legend(ncol=3)

# plt.show()

# import matplotlib.pyplot as plt
# import matplotlib
# matplotlib.rcParams['font.family'] = 'Malgun Gothic' # Windows
# # matplotlib.rcParams['font.family'] = 'AppleGothic' # Mac
# matplotlib.rcParams['font.size'] = 15 # 글자 크기
# matplotlib.rcParams['axes.unicode_minus'] = False # 한글 폰트 사용 시, 마이너스 글자가 깨지는 현상을 해결

# labels = ['홍길동', '박문수', '임꺽정'] # 이름
# values = [190, 187, 184] # 키

# # plt.barh(labels, values)
# # plt.xlim(175, 195)

# bar = plt.bar(labels, values)
# plt.ylim(175, 195)

# for idx, rect in enumerate(bar):
#     plt.text(idx, rect.get_height() + 0.5, values[idx], ha='center', color='blue')

# plt.show()

# import matplotlib.pyplot as plt
# import matplotlib
# matplotlib.rcParams['font.family'] = 'Malgun Gothic' # Windows
# # matplotlib.rcParams['font.family'] = 'AppleGothic' # Mac
# matplotlib.rcParams['font.size'] = 15 # 글자 크기
# matplotlib.rcParams['axes.unicode_minus'] = False # 한글 폰트 사용 시, 마이너스 글자가 깨지는 현상을 해결

# values = [30, 25, 20, 13, 10, 2]
# labels = ['Python', 'Java', 'Javascript', 'C#', 'C/C++', 'ETC']
# # colors = ['b', 'g', 'r', 'c', 'm', 'y']
# colors = ['#ffadad', '#ffd6a5', '#fdffb6', '#caffbf', '#9bf6ff', '#a0c4ff']
# explode = [0.05] * 6

# plt.pie(values, labels=labels, autopct='%.1f%%', startangle=90, counterclock=False, colors=colors, explode=explode)
# plt.show()

### Quizzes
## 데이터 준비

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['font.family'] = 'Malgun Gothic' # Windows
# matplotlib.rcParams['font.family'] = 'AppleGothic' # Mac
matplotlib.rcParams['font.size'] = 15
matplotlib.rcParams['axes.unicode_minus'] = False

data = {
    '영화' : ['명량', '극한직업', '신과함께-죄와 벌', '국제시장', '괴물', '도둑들', '7번방의 선물', '암살'],
    '개봉 연도' : [2014, 2019, 2017, 2014, 2006, 2012, 2013, 2015],
    '관객 수' : [1761, 1626, 1441, 1426, 1301, 1298, 1281, 1270], # (단위 : 만 명)
    '평점' : [8.88, 9.20, 8.73, 9.16, 8.62, 7.64, 8.83, 9.10]
}
df = pd.DataFrame(data)
# print(df)

## 영화 데이터를 활용하여 x 축은 영화, y 축은 평점인 막대 그래프
# plt.bar(df['영화'], df['평점'])
# plt.show()

# plt.bar(df['영화'], df['평점'])
# plt.title('국내 Top 8 영화 평점 정보')
# plt.xlabel('영화')
# plt.xticks(rotation=90)
# plt.ylabel('평점')
# plt.show()

## 개봉 연도별 평점 변화 추이를 꺾은선 그래프
# df_group = df.groupby('개봉 연도').mean()
# # # print(df_group)
# # plt.plot(df_group.index, df_group['평점'])
# # plt.show()

# plt.plot(df_group.index, df_group['평점'], marker='o')
# plt.xticks([2005, 2010, 2015, 2020])
# plt.ylim(7, 10)
# plt.show()

## 평점이 9점 이상인 영화의 비율을 확인할 수 있는 원 그래프
# filt = df['평점'] >= 9.0
# values = [len(df[filt]), len(df[~filt])]
# labels = ['9점 이상', '9점 미만']

# plt.pie(values, labels=labels, autopct='%.1f%%')
# plt.legend(loc=(1, 0.3))
# plt.show()