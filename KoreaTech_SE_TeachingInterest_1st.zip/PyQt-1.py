import sys
from PyQt5.QtWidgets import *

app = QApplication(sys.argv)
qw = QWidget()
qw.show()
sys.exit(app.exec_())