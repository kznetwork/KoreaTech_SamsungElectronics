###
# import sys
# print("python 버전 : {}".format(sys.version))

###
#print(1+1)  # 모두 붙여쓰지 않는다.

# print(1 + 1)   # 너무 많이 띄우지 않는다. 한 칸만 띄운다.

###
# import keyword

# print(keyword.kwlist)

###
# if True:
#     print("Answer")
#     print("True") 
# else:
#     print("Answer")
#     print("False") 

# if True:
#     print("Answer")
#     print("True") 
# else:
#         print("Answer")
#     print("False") 

###
# total = 'item_one, ' + \
#         'item_two, ' + \
#         'item_three'

# print(total)

###
# days = ['Monday', 'Tuesday',
#         'Wednesday', 'Thursday', 'Friday']
# print(days)


###
# word = 'word'
# sentence = "This is a sentence."
# paragraph = """This is a paragraph. It is
# made up of multiple lines and sentences."""
# print(word)
# print(sentence)
# print(paragraph)

###
# First comment
#print("Hello, Python!")  # second comment
# last comment

###
#!/usr/bin/env python3
# print("I'm excited to learn Python.")

# 4 + 5

# print(4 + 5) 

# # two numbers 더 하기
# x = 4
# y = 5
# z = x+y
# print("Four plus five equals {0:d}.".format(z))


###
# lists 더하기
# a = [1, 2, 3, 4]
# b = ["first", "second", "third", "fourth"]
# c = a+b
# print("Output #1: {0}, {1}, {2}".format(a, b, c))

# print("Output #2: ",a,", ",b,", ",c)

###
# print(7 + 4)  # 7 더하기 4는 11

# print(7 - 4) # 7 빼기 4는 3

# print(7 * 4) # 7 곱하기 4는 28

# print(7 // 4) # 7을 4로 나눈 몫은 1

# print(7 / 4) # 7을 4로 나눈 몫 실수값 1.75

# print(7 % 4) # 7을 4로 나눈 나머지는 3

# print(7 ** 4) # 네제곱 2401

# print(7 ** -4) # 음수 제곱은 역수 7^(-4)

# print(7 ** 0) # 모든 수의 0 제곱은 1

###
# print(1.1 + 2.4)
# print(4.2 - 1.2)
# print(1.2 * 2.2)
# print(5.4 / 2.7)


###
# Quiz: 사칙연산
# 현재 5000원이 있고 사탕의 가격이 120원이라고 하자. 최대한 살 수 있는 사탕의 개수와 나머지 돈은 얼마인가?

# myMoney = 5000;
# print(myMoney)
# candyPrice = 120;
# print(candyPrice)
# #최대한 살 수 있는 사탕 수 계산식? 갖고 있는 돈 // 사탕 가격
# numCandies = myMoney // candyPrice
# print(numCandies)
# print('5000원으로 120원짜리 사탕을 최대한 살 수 있는 갯수 =', numCandies)
# #그렇다면, 남은 돈은 얼마일까?
# change = myMoney % candyPrice;
# print(change)
# print("5000원으로 120원짜리 사탕을 사고 남은 돈은 =", change)

###
# print(3 + 2 * 4)
# print(3 + (2 * 4))
# print((3 + 2) * 4)

#Quiz

# print(100 / (3 * (10 - (3 * 2)) + 8))

###
# print(10 > 3) # True
# print(4 >= 7) # False
# print(10 < 3) # False
# print(5 <= 5) # True

# # 좌항과 우항이 같은지 비교
# print(3 == 3) # 같으므로 True
# print(4 == 2) # 다르므로 False
# print(3 + 4 == 7) # 같으므로 True

# # 좌항과 우항이 다른지 비교
# print(1 != 3) # 다르므로 True

# # 좌항과 우항이 모두 참인가?
# print((3 > 0) and (3 > 5)) # 좌항(3 > 0) 은 참이지만 우항(3 > 5) 는 거짓이므로 False 

# # 좌항 또는 우항 중 하나라도 참인가?
# print((3 > 0) or (3 > 5)) # 좌항(3 > 0) 이 참이므로 우항(3 > 5) 이 거짓이라도 True

# # 좌항과 우항이 다른지 비교한 결과의 반대
# print(not(1 != 3)) # 1과 3은 다르므로 True 인데, True 의 반대이므로 False

# print(5 > 4 > 3) # (5 > 4) 도 참이며 (4 > 3) 도 참이므로 True
# print(5 > 4 > 7) # (5 > 4) 는 참이지만 (4 > 7) 은 거짓이므로 False


###
# 좌항과 우항이 모두 참인가?
# print((3 > 0) and (3 > 5)) # 좌항(3 > 0) 은 참이지만 우항(3 > 5) 는 거짓이므로 False 

# # 좌항 또는 우항 중 하나라도 참인가?
# print((3 > 0) or (3 > 5)) # 좌항(3 > 0) 이 참이므로 우항(3 > 5) 이 거짓이라도 True

# # 좌항과 우항이 다른지 비교한 결과의 반대
# print(not(1 != 3)) # 1과 3은 다르므로 True 인데, True 의 반대이므로 False

# # 연속적인 수식에 대해서도 연산이 가능
# print(5 > 4 > 3) # (5 > 4) 도 참이며 (4 > 3) 도 참이므로 True
# print(5 > 4 > 7) # (5 > 4) 는 참이지만 (4 > 7) 은 거짓이므로 False

###
# number = 2 + 3 * 4 # 14
# print(number)

# # 2를 더하려면 어떻게 하면 될까요?
# number = number + 2 # 16
# print(number)

# # 다른 방법
# number += 2 # number = number + 2 와 동일
# print(number) # 18

# # 다른 연산자
# number *= 2 # number = number * 2 와 동일
# print(number) # 36

# number /= 2 # number = number / 2 와 동일
# print(number) # 18

# number -= 2 # number = number - 2 와 동일
# print(number) # 16

# number %= 2 # number = number % 2 와 동일
# print(number) # 0

###
# print(1, 2, 3, 4, 5)
# print("사과", "배", "포도", "바나나", "딸기")
# print("ColombianMilds","EthiopianHarrar","EthiopianYirgacheffe","HawaiianKona","JamaicanBlueMountain")


###
# print(1 + 4)

# number1 = int(input("첫 번째 숫자를 입력하시오: "))
# number2 = int(input("두 번째 숫자를 입력하시오: "))
# print(number1, number2)
# print(number1 + number2)
# print("숫자 1과 숫자 2의 합은 :", number1 + number2)
# print("숫자 1과 숫자 2의 합은 : {}".format(number1 + number2))

###
# x = 1         # x는 정수입니다.
# x = 'hello'   # 여기서는 x가 문자열입니다.
# x = [1, 2, 3] # 여기서는 x가 리스트입니다.
# print(x)

# a=10
# b=10
# print(a, b)
# print(a is b)
# print(id(a), id(b))
# b = 30
# print(a, b)
# print(a is b)
# print(id(a), id(b))
# b = 10
# print(a, b)
# print(a is b)
# print(id(a), id(b))

###
# TAX_RATE = 0.35
# PI = 3.141592
# MAX_SIZE = 100
# print(TAX_RATE,PI,MAX_SIZE )
# TAX_RATE = 0.35
# print(TAX_RATE)
# TAX_RATE = 100
# print(TAX_RATE)

# from typing import Final
# a: Final = 1    
# print(a)

# a = 2
# print(a)


###
# print("I have", "pens.")
# print("I have" + "pens.")
# #print("I have" + 2 + "pens.")
# print("I have" + str(2) + "pens.")

# print(1 + 3)
# #print(1 + "3")
# print(1 + int("3"))

###

# a = 1 + 2j

# print(a.real)   #‘.real’은 복소수의 실수 부분 반환
# print(a.imag)   #‘.imag’는 복소수의 허수 부분 반환
# print(a.conjugate())    #‘.conjugate()’는 복소수의 켤레 복소수 반환
# print(abs(a))   #‘.abs(복소수)’는 복소수의 절대값 반환

# from sys import getsizeof

# a=1
# print(getsizeof(a))

# b = "I"
# print(getsizeof(b))

###
# print(type(None))
# print(type(True))
# print(type(1))
# print(type(3.141592))
# print(type(2 + 3j))
# print(type("abc"))
# print(type((1, 2, 3)))
# print(type([1, 2, 3]))
# print(type({"A": 10, "B": 20, "C":30}))

###
# print('py'+'thon')
# print('py''thon')
# print('py'*3)

# print('python'[0])
# print('python'[5])
# print('python'[1:4])
# print('python'[1:4])

###
# 주민등록번호 사례 : 230101-1234567
# residentRegistrationNumber = "230131-1234567"

# print("성별 : " + residentRegistrationNumber[7]) # 성별 : 1
# print("연 : " + residentRegistrationNumber[0:2]) # 0 부터 2 직전까지 (0, 1) : 99 년
# print("월 : " + residentRegistrationNumber[2:4]) # 2 부터 4 직전까지 (2, 3) : 01 월
# print("일 : " + residentRegistrationNumber[4:6]) # 4 부터 6 직전까지 (4, 5) : 20 일

# print("생년월일 : " + residentRegistrationNumber[:6]) # 처음부터 6 직전까지 -> jumin[0:6] 과 동일
# print("뒤 7자리 : " + residentRegistrationNumber[7:]) # 7 부터 끝까지 -> jumin[7:14] 와 동일



###
# print(10)  # 정수
# print(10.0)  # 실수
# print(.1)  # .1 = 0.1
# print(10 * 5)  # 정수
# print(10.0 * 5)  # 실수
# print(10 / 5)  # 실수
# print(type(10))
# print(type(10.0))
# print(123e2)  # 123e2 = 123.0 x 100 = 12300.0
# print(123e-2) # 123e-2 = 123.0 x 0.01 = 1.23
# print(123.456e-3)  # 123.456e-3 = 123.456 x 0.001 = 0.123456

###
# print(int(1.0))  # 실수를 정수로 변환
# print(float(1))  # 정수를 실수로 변환
# print(int(3.14))
# print(int(3.9))
# print(int(-3.9))
# print(float("NaN"))
# print(float("Inf"))
# print(float("-Inf"))


###
# Quiz : 변수 값 교환

# x = 10
# y = 20
# print("x = {}, y = {}".format(x,y))

# temp= x
# x = y
# y= temp

# print("x = {}, y = {}".format(x,y))

###
# print("Hello!")
# print('한글도 쓸 수 있어요.')

# print("내 이름은 " + "홍길동" + "입니다.")

# print("*" * 10)
# n = 10
# print("별표를 " + str(n) + "번 출력합니다.")
# print("*" * n)

# print("한 줄 쓰고\n그 다음 줄을 쓴다.")
# print("한 줄 쓰고 ", end="")
# print("이어서 쓴다.")

# name = "홍길동"
# print("내 이름은 " + name + "입니다.")
# mark = "$"
# n = 20
# print(mark + " 기호를 " + str(n) + "번 출력합니다.")
# print(mark * n)

# print('둘리가 "호이!"하고 말했어요.')
# print("둘리가 '이제 어디로 가지?'하고 생각했어요.")
# # print("둘리가 "호이!"하고 말했어요")
# print("둘리가 \"호이!\"하고 말했어요")

###
print("Life is short, You need Python.")
print("Life is short,\n You need Python.")
print("Pine \"Apple\"입니다.") # Pine"Apple"입니다.
print("C:\\Users\\DaeKyeong\\Desktop\\PythonWorkspace>") # C:\Users\DaeKyeong\Desktop\PythonWorkspace>
print("Red Apple\rPine") # PineApple
print("Redd\bApple") # RedApple
print("Red\tApple") # Red     Apple

# multi_line_string = """
# 파이썬(영어: Python)은 1991년 프로그래머인 
# 귀도 반 로섬(Guido van Rossum)이 발표한 고급 프로그래밍 언어로,
# 플랫폼 독립적이며 인터프리터식, 객체지향적, 동적 타이핑(dynamically typed) 
# 대화형 언어이다. 파이썬이라는 이름은 귀도가 좋아하는 코미디 〈Monty Python's Flying 
# Circus〉에서 따온 것이다."""

# print(multi_line_string)

# print("2023.03.01".replace(".","-"))
# print("word with space".replace(" ",""))

###
# python = "Life is short, You need Python."

# print(python.lower()) 
# print(python.upper()) 
# print(python[0].isupper()) # True : 0 번째 인덱스의 값이 대문자인지 확인
# print(len(python)) # 17 : 띄어쓰기를 포함한 문자열의 전체 길이 (length)
# print(python.replace("Python", "Java")) 
# index = python.index("n") # 처음으로 발견된 n 의 인덱스
# print(index) # 5 : Python 의 n
# index = python.index("n", index + 1) # 6 번째 인덱스 이후에 처음으로 발견된 n 의 인덱스 
# print(index) 
# find = python.find("n") # 처음으로 발견된 n 의 인덱스
# print(find) # 5 : Python 의 n
# find = python.find("n", find + 1) # 6 번째 인덱스 이후에 처음으로 발견된 n 의 인덱스 
# print(find) 
# #print(python.index("Java")) # Java 가 없기 때문에 에러가 발생하며 프로그램 종료
# print(python.find("Java")) # Java 가 없으면 -1 을 반환(출력)하며 프로그램 계속 수행
# print(python.count("n")) # 2 : 문자열 내에서 n 이 나온 횟수


###
# 방법 1

# print("나는 %d살입니다." % 20) # 나는 20살입니다
# print("나는 %s을 좋아합니다." % "파이썬") # 나는 파이썬을 좋아합니다.
# print("Apple 은 %c로 시작해요." % "A") # Apple 은 A로 시작해요.

# print("나는 %s살입니다." % 20) # 나는 20살입니다 (%s 로도 정수값 표현 가능)

# print("나는 %s색과 %s색을 좋아해요." % ("파란", "빨간")) # 나는 파란색과 빨간색을 좋아해요.


# 방법 2

# print("나는 {}살입니다.".format(20)) # 나는 20살입니다.
# print("나는 {}색과 {}색을 좋아해요.".format("파란", "빨간")) # 나는 파란색과 빨간색을 좋아해요
# print("나는 {0}색과 {1}색을 좋아해요.".format("파란", "빨간")) # 나는 파란색과 빨간색을 좋아해요
# print("나는 {1}색과 {0}색을 좋아해요.".format("파란", "빨간")) # 나는 빨간색과 파란색을 좋아해요

# 방법 3

# print("나는 {age}살이며, {color}색을 좋아해요.".format(age=20, color="빨간"))
# # 나는 20살이며, 빨간색을 좋아해요

# print("나는 {age}살이며, {color}색을 좋아해요.".format(color="빨간", age=20))
# # 나는 20살이며, 빨간색을 좋아해요 (.format 뒤에 순서를 변경해도 괜찮아요)

# 방법 4 (파이썬 버전 3.6 부터 가능)

# age = 20
# color = "빨간"
# print(f"나는 {age}살이며, {color}색을 좋아해요.") # 나는 20살이며, 빨간색을 좋아해요.


###
# Quiz: 비밀번호 생성
# 사이트 별로 비밀번호를 만들어주는 프로그램을 작성하시오.

# 예) http://naver.com
# 규칙1 : http:// 부분은 제외 → naver.com
# 규칙2 : 처음 만나는 점(.) 이후 부분은 제외 → naver
# 규칙3 : 남은 글자 중 처음 세 자리 + 글자 갯수 + 글자 내 'e'의 갯수 + '!'로 구성
#                        (nav)                      (5)                   (1)             (!)

# 예) 생성된 비밀번호 : nav51!

# 프로그램을 실행했을 때 나와야 하는 출력값은 다음과 같습니다.
# http://naver.com 일 때
#  → nav51!
# http://google.com 일 때
#  → goo61!

# URL = "http://naver.com"
# # URL = "http://daum.net"
# # URL = "http://google.com"

# http_url = URL.replace("http://", "") # 규칙 1

# http_url = http_url[:http_url.index(".")] # 규칙 2
# # naver.com 일 때 http_url.index(".") 의 결과는 5 이므로 위 문장은
# # http_url = mystr[0:5] 와 같음

# http_pass = http_url[:3] + str(len(http_url)) + str(http_url.count("e")) + "!" # 규칙 3

# print("{0} 의 비밀번호는 {1} 입니다.".format(URL, http_pass))
