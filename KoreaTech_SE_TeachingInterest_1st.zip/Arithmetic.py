num1 = int(input("첫번째 정수값 >> "))
operator = input("연산자 >> ")
num2 = int(input("두번째 정수값 >> "))

if operator == '+':
    result = num1 + num2
    operator_str = '더하기'
elif operator == '-':
    result = num1 - num2
    operator_str = '빼기'
elif operator == '*':
    result = num1 * num2
    operator_str = '곱하기'
elif operator == '/':
    result = num1 / num2
    operator_str = '나누기'
else:
    print("잘못된 연산자입니다.")
    exit()

print("==========================")
print(f"{num1} {operator_str} {num2}을 계산합니다.")
print("==========================")
print(f"{num1} {operator} {num2} = {result}입니다.")
