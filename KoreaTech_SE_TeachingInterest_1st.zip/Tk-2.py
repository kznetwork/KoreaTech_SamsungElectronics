from tkinter import *

root = Tk() # GUI 생성 
root.title("tkinter_practice") #상단의 타이틀 지정
root.geometry("640x640") # 크기 설정 (640x640) 
root.mainloop() # GUI가 보이고 종료될때까지 실행함